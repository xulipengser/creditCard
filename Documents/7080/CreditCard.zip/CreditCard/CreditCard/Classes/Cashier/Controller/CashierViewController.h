//
//  CashierViewController.h
//  CreditCard
//
//  Created by cass on 2018/3/24.
//  Copyright © 2018年 廖智尧. All rights reserved.
//

#import "BaseViewController.h"
#import "UserModel.h"
@interface CashierViewController : UIViewController
@property(nonatomic, strong) UserModel *userModel;
@end
