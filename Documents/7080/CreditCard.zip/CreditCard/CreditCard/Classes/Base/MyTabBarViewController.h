//
//  MyTabBarViewController.h
//  MyNewWeibo
//
//  Created by LiaoZhiyao on 15/9/11.
//  Copyright (c) 2015年 LiaoZhiyao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyTabBarViewController : UITabBarController

@end
