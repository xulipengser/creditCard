//
//  RealNameCertModel.m
//  CreditCard
//
//  Created by 廖智尧 on 2018/3/14.
//  Copyright © 2018年 廖智尧. All rights reserved.
//

#import "RealNameCertModel.h"

@implementation RealNameCertModel

@end
