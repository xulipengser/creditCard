//
//  RegisteVC.h
//  CreditCard
//
//  Created by 廖智尧 on 2018/3/28.
//  Copyright © 2018年 廖智尧. All rights reserved.
//

#import "NBLWebViewController.h"

@interface RegisteVC : NBLWebViewController

@end
