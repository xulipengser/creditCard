//
//  WithdrawalRecordVC.h
//  CreditCard
//
//  Created by 廖智尧 on 2018/3/31.
//  Copyright © 2018年 廖智尧. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UserModel.h"
@interface WithdrawalRecordVC : UIViewController
@property(nonatomic, strong) UserModel *userModel;
@end
