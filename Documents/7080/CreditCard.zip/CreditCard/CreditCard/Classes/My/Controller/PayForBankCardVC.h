//
//  PayForBankCardVC.h
//  CreditCard
//
//  Created by 廖智尧 on 2018/3/29.
//  Copyright © 2018年 廖智尧. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AccountUpdateModel.h"
@interface PayForBankCardVC : UIViewController
@property(nonatomic, strong) AccountUpdateModel *model;
@end
