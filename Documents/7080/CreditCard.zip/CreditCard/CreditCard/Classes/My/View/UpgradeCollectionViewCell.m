//
//  UpgradeCollectionViewCell.m
//  CreditCard
//
//  Created by 廖智尧 on 2018/2/12.
//  Copyright © 2018年 廖智尧. All rights reserved.
//

#import "UpgradeCollectionViewCell.h"

@implementation UpgradeCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
