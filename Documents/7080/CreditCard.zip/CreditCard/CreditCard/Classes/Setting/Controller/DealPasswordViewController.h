//
//  DealPasswordViewController.h
//  CreditCard
//
//  Created by cass on 2018/3/25.
//  Copyright © 2018年 廖智尧. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DealPasswordViewController : UIViewController
@property (nonatomic) NSInteger type;

@end
