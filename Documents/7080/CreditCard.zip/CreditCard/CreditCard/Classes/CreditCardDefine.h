//
//  CreditCardDefine.h
//  CreditCard
//
//  Created by cass on 2018/3/24.
//  Copyright © 2018年 廖智尧. All rights reserved.
//

#ifndef CreditCardDefine_h
#define CreditCardDefine_h

typedef enum : NSUInteger {
    CardTypeCreditCard = 0,
    CardTypeDebitCard = 1
} CardType;
#endif /* CreditCardDefine_h */
