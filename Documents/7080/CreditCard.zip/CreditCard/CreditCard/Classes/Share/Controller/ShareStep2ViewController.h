//
//  ShareStep2ViewController.h
//  CreditCard
//
//  Created by 廖智尧 on 2018/2/12.
//  Copyright © 2018年 廖智尧. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShareStep2ViewController : UIViewController
- (instancetype)initWithImg:(UIImage *)img;
@end
