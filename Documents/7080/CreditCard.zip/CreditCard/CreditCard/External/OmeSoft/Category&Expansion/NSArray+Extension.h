//
//  NSArray+Extension.h
//  CounterTest
//
//  Created by 廖智尧 on 2017/11/15.
//  Copyright © 2017年 廖智尧. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (Extension)
+ (instancetype)getProperties:(Class)cls;
@end
