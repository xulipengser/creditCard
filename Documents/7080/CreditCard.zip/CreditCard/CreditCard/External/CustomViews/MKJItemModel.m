//
//  MKJItemModel.m
//  PhotoAnimationScrollDemo
//
//  Created by MKJING on 16/8/9.
//  Copyright © 2016年 MKJING. All rights reserved.
//

#import "MKJItemModel.h"

@implementation MKJItemModel

@end
