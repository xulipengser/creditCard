//
//  MKJCircleLayout.h
//  PhotoAnimationScrollDemo
//
//  Created by 宓珂璟 on 2017/1/26.
//  Copyright © 2017年 MKJING. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MKJCircleLayout : UICollectionViewLayout

@end
