
//
//  NBLWebViewHeader.h
//  NBLWebViewControllerDemo
//
//  Created by neebel on 2017/10/27.
//  Copyright © 2017年 neebel. All rights reserved.
//

#ifndef NBLWebViewHeader_h
#define NBLWebViewHeader_h

//method name key
#define methodNameKey @"methodName"

//params key
#define paramsKey     @"params"

//callback method key

#define callbackMethodKey  @"callbackMethod"

#endif /* NBLWebViewHeader_h */
